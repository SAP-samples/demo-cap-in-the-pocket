sap.ui.define(["sap/fe/core/AppComponent"], function (BaseComponent) {
  "use strict";

  /**
   * @namespace sap.fe.cap.travel_analytics
   */
  const Component = BaseComponent.extend("sap.fe.cap.travel_analytics.Component", {
    metadata: {
      manifest: "json"
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
